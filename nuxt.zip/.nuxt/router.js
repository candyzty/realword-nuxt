import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _1deed495 = () => interopDefault(import('../pages/layout' /* webpackChunkName: "" */))
const _3bb22d0a = () => interopDefault(import('../pages/home' /* webpackChunkName: "" */))
const _3acbbc9e = () => interopDefault(import('../pages/login' /* webpackChunkName: "" */))
const _e01444c4 = () => interopDefault(import('../pages/profile' /* webpackChunkName: "" */))
const _0005e6ce = () => interopDefault(import('../pages/settings' /* webpackChunkName: "" */))
const _121ffad8 = () => interopDefault(import('../pages/editor' /* webpackChunkName: "" */))
const _76c020eb = () => interopDefault(import('../pages/article' /* webpackChunkName: "" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _1deed495,
    children: [{
      path: "/",
      component: _3bb22d0a,
      name: "home"
    }, {
      path: "/login",
      component: _3acbbc9e,
      name: "login"
    }, {
      path: "/register",
      component: _3acbbc9e,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _e01444c4,
      name: "profile"
    }, {
      path: "/settings",
      component: _0005e6ce,
      name: "settings"
    }, {
      path: "/editor",
      component: _121ffad8,
      name: "editor"
    }, {
      path: "/article/:articleName",
      component: _76c020eb,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
